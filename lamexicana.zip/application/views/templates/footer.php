<footer class="bg-dark text-white text-center mt-5 p-3">
    <p>&copy; <?= date('Y') ?> Mi Empresa. Todos los derechos reservados.</p>
</footer>

<script src="<?= base_url('assets/js/jquery.min.js') ?>"></script>
<script src="<?= base_url('assets/js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
