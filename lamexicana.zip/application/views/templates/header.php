<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Empresa</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    
</head>
<body>

<!-- ENCABEZADO -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="<?= base_url() ?>">Mi Empresa</a>
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav ml-auto">
      <?php if(!empty($menu)): ?>
        <?php foreach($menu as $m): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url($m->url ?? '#') ?>">
              <?= $m->nombre ?>
            </a>
          </li>
        <?php endforeach; ?>
      <?php endif; ?>
    </ul>
  </div>
</nav>
