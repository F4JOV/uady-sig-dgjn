<style>
  .carousel-item img {
      width: 100%;           
      max-height: 150px;     
      object-fit: cover;     
      border-radius: 12px;   
  }
</style>

<?php if (!empty($carousel)): ?>
<div id="mainCarousel" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <?php $active = 'active'; ?>
    <?php foreach ($carousel as $c): ?>
      <div class="carousel-item <?= $active ?>">
        <a href="<?= !empty($c->href) ? $c->href : '#' ?>">
          <img 
            src="https://www.abarroteslamexicana.mx<?= $c->ruta ?>" 
            class="d-block w-100" 
            alt="Imagen <?= $c->id ?>"
            >

        </a>
      </div>
      <?php $active = ''; ?>
    <?php endforeach; ?>
  </div>

  <a class="carousel-control-prev" href="#mainCarousel" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Anterior</span>
  </a>
  <a class="carousel-control-next" href="#mainCarousel" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Siguiente</span>
  </a>
</div>
<?php endif; ?>
