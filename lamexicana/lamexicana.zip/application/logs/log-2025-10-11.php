<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-11 00:42:01 --> 404 Page Not Found: /index
ERROR - 2025-10-11 00:45:54 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:45:54 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:45:54 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:45:54 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:45:54 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:45:54 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:45:54 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:45:54 --> Severity: 8192 --> strtolower(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:00 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:00 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:49:00 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:00 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:49:00 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:00 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:49:00 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:00 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:49:07 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:49:07 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:49:07 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:49:07 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 19
ERROR - 2025-10-11 00:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:50:03 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 22
ERROR - 2025-10-11 00:50:03 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:50:03 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 22
ERROR - 2025-10-11 00:50:03 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:50:03 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 22
ERROR - 2025-10-11 00:50:04 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:50:04 --> Severity: Warning --> Undefined property: stdClass::$url C:\xampp\htdocs\lamexicana\application\views\templates\header.php 22
ERROR - 2025-10-11 00:50:04 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\lamexicana\system\core\Config.php 335
ERROR - 2025-10-11 00:54:38 --> 404 Page Not Found: Sucursales/index
ERROR - 2025-10-11 00:56:07 --> 404 Page Not Found: Sucursales/index
ERROR - 2025-10-11 01:00:47 --> 404 Page Not Found: Sucursales/index
