<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-09 07:46:28 --> Severity: Warning --> odbc_connect(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Cannot open database &quot;lamexicana&quot; requested by the login. The login failed., SQL state 37000 in SQLConnect C:\xampp\htdocs\empresa\system\database\drivers\odbc\odbc_driver.php 125
ERROR - 2025-10-09 07:46:28 --> Unable to connect to the database
