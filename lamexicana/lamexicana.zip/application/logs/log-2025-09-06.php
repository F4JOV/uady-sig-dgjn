<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-06 00:01:19 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=11344 C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-06 00:01:19 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=11344 C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-06 00:01:19 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=11344 C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-09-06 00:01:19 --> Severity: error --> Exception: MySQL server has gone away C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-09-06 00:01:19 --> Severity: error --> Exception: MySQL server has gone away C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-09-06 00:01:19 --> Severity: error --> Exception: MySQL server has gone away C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-09-06 02:14:18 --> 404 Page Not Found: Parisjpg/index
ERROR - 2025-09-06 02:14:18 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-06 02:14:18 --> 404 Page Not Found: Sanfranjpg/index
ERROR - 2025-09-06 02:17:34 --> Severity: Warning --> Undefined variable $base_url C:\xampp\htdocs\empresa\application\views\company.php 117
ERROR - 2025-09-06 02:17:34 --> 404 Page Not Found: Parisjpg/index
ERROR - 2025-09-06 02:17:34 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-06 02:17:34 --> 404 Page Not Found: Sanfranjpg/index
ERROR - 2025-09-06 02:20:35 --> Severity: Warning --> Undefined variable $base_url C:\xampp\htdocs\empresa\application\views\company.php 117
ERROR - 2025-09-06 02:20:35 --> 404 Page Not Found: Newyorkjpg/index
ERROR - 2025-09-06 02:20:35 --> 404 Page Not Found: Sanfranjpg/index
ERROR - 2025-09-06 02:27:52 --> Severity: Warning --> Undefined variable $base_url C:\xampp\htdocs\empresa\application\views\company.php 117
ERROR - 2025-09-06 02:27:52 --> Severity: error --> Exception: Value of type null is not callable C:\xampp\htdocs\empresa\application\views\company.php 117
ERROR - 2025-09-06 02:27:57 --> Severity: Warning --> Undefined variable $base_url C:\xampp\htdocs\empresa\application\views\company.php 117
ERROR - 2025-09-06 02:27:57 --> Severity: error --> Exception: Value of type null is not callable C:\xampp\htdocs\empresa\application\views\company.php 117
ERROR - 2025-09-06 02:40:49 --> Severity: error --> Exception: syntax error, unexpected token "{", expecting "(" C:\xampp\htdocs\empresa\application\controllers\Company.php 40
ERROR - 2025-09-06 02:45:44 --> Severity: error --> Exception: syntax error, unexpected token "{", expecting "(" C:\xampp\htdocs\empresa\application\controllers\Company.php 40
