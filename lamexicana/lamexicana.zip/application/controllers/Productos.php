<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Productos extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('MPrincipal', 'mP');
    }

    public function index(){
        
        $data['menu'] = $this->mP->get_menu();

        
        $data['carousel'] = $this->mP->get_carousel();

        
        $data['contenido'] = $this->mP->consultar_seccion(6);

        
        $this->load->view('templates/header', $data);
        $this->load->view('home', $data);
        $this->load->view('templates/footer', $data);
    }
}
