<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>La mexicana</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <!-- Tu CSS personalizado -->
    <link rel="stylesheet" href="<?= base_url('assets/css/header.css') ?>">
</head>
<body>

<!-- ENCABEZADO -->
<nav class="navbar navbar-expand-lg navbar-dark custom-navbar sticky-top">
  <a class="navbar-brand" href="<?= base_url('home') ?>">La Mexicana</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <?php if(!empty($menu)): ?>
        <?php foreach($menu as $m): ?>
          <li class="nav-item <?= ($this->uri->segment(1) == $m->url) ? 'active' : '' ?>">
            <a class="nav-link" href="<?= base_url($m->url ?? '#') ?>">
              <?= $m->nombre ?>
            </a>
          </li>
        <?php endforeach; ?>
      <?php endif; ?>
    </ul>
  </div>
</nav>
