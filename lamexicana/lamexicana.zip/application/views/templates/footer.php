<footer class="bg-dark text-white text-center mt-5 p-3">
    <p>&copy; <?= date('Y') ?> Mi Empresa. Todos los derechos reservados.</p>
</footer>


</body>
</html>
