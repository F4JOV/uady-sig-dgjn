<div class="container-fluid">
    <div class="row">
        <div class="col-sm-6 text-center">
            <h1>TITLE</h1>
            <p>text</p>
        </div>
        <div class="col-sm-6 text-center">
            <h1>TITLE 2</h1>
            <p>text 2</p>
        </div>
    </div>
</div>
