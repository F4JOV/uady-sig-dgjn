<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-10 21:18:16 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_contenido_x_idseccion'., SQL state 37000 in SQLExecDirect C:\xampp\htdocs\lamexicana\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-10 21:18:16 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Could not find stored procedure 'pa_consultar_contenido_x_idseccion'. - Invalid query: exec pa_consultar_contenido_x_idseccion @idseccion='1'
ERROR - 2025-10-10 21:24:20 --> 404 Page Not Found: /index
ERROR - 2025-10-10 21:24:52 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'menu'., SQL state S0002 in SQLExecDirect C:\xampp\htdocs\lamexicana\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-10 21:24:52 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid object name 'menu'. - Invalid query: SELECT * FROM menu WHERE estatus = 1 ORDER BY orden
ERROR - 2025-10-10 21:26:06 --> Severity: Warning --> Undefined property: stdClass::$titulo C:\xampp\htdocs\lamexicana\application\views\home.php 8
ERROR - 2025-10-10 21:26:06 --> Severity: Warning --> Undefined property: stdClass::$texto C:\xampp\htdocs\lamexicana\application\views\home.php 9
ERROR - 2025-10-10 21:28:34 --> Severity: Warning --> Undefined property: stdClass::$titulo C:\xampp\htdocs\lamexicana\application\views\home.php 8
ERROR - 2025-10-10 21:28:34 --> Severity: Warning --> Undefined property: stdClass::$texto C:\xampp\htdocs\lamexicana\application\views\home.php 9
ERROR - 2025-10-10 21:30:13 --> Severity: Warning --> Undefined property: stdClass::$titulo C:\xampp\htdocs\lamexicana\application\views\home.php 8
ERROR - 2025-10-10 21:30:13 --> Severity: Warning --> Undefined property: stdClass::$texto C:\xampp\htdocs\lamexicana\application\views\home.php 9
ERROR - 2025-10-10 21:44:30 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'orden'., SQL state S0022 in SQLExecDirect C:\xampp\htdocs\lamexicana\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-10 21:44:30 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'orden'. - Invalid query: SELECT nombre FROM cat_menu WHERE estatus = 1 ORDER BY orden
