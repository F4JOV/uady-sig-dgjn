<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('MPrincipal', 'mP');
    }

    public function index(){
        // Datos del encabezado (menú principal)
        $data['menu'] = $this->mP->get_menu();

        // Datos del carrusel
        $data['carousel'] = $this->mP->get_carousel(1);

        // Contenido principal (puede ser la sección de inicio)
        $data['contenido'] = $this->mP->consultar_seccion(1);

        // Carga de vistas
        $this->load->view('templates/header', $data);
        $this->load->view('home', $data);
        $this->load->view('templates/footer', $data);
    }
}
