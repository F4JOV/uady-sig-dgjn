<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MainController extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('MPrincipal', 'mP');
    }

    public function index(){
        // Datos del encabezado (menú principal)
        $data['menu'] = $this->mP->get_menu();

        // Datos del carrusel
        $data['carousel'] = $this->mP->get_carousel(1);

        // Contenido principal (puede ser la sección de inicio)
        $data['contenido'] = $this->mP->consultar_seccion(1);
        $data['contacto'] = $this->mP->get_contacto();

        // Carga de vistas
        $this->load->view('templates/header', $data);
        $this->load->view('home', $data);
        $this->load->view('templates/footer', $data);
    }

    public function productos(){
        
        $data['menu'] = $this->mP->get_menu();
        $data['carousel'] = $this->mP->get_carousel(3);
        $data['contenido'] = $this->mP->consultar_seccion(6);
        $data['contacto'] = $this->mP->get_contacto();
        
        $this->load->view('templates/header', $data);
        $this->load->view('productos', $data);
        $this->load->view('templates/footer', $data);
    }

    public function mision(){
        
        $data['menu'] = $this->mP->get_menu();
        $data['carousel'] = $this->mP->get_carousel(2);
        $data['contenido'] = $this->mP->consultar_seccion(2);
        $data['contacto'] = $this->mP->get_contacto();
        
        $this->load->view('templates/header', $data);
        $this->load->view('mision', $data);
        $this->load->view('templates/footer', $data);
    }

    public function actualidad(){
        
        $data['menu'] = $this->mP->get_menu();
        $data['carousel'] = $this->mP->get_carousel(5);
        $data['contenido'] = $this->mP->consultar_seccion(5);
        $data['contacto'] = $this->mP->get_contacto();

        
        $this->load->view('templates/header', $data);
        $this->load->view('actualidad', $data);
        $this->load->view('templates/footer', $data);
    }

    public function sucursales(){
        
        $data['menu'] = $this->mP->get_menu();
        $data['carousel'] = $this->mP->get_carousel(7);
        $data['contenido'] = $this->mP->consultar_seccion(7);
        $data['contacto'] = $this->mP->get_contacto();

        
        $this->load->view('templates/header', $data);
        $this->load->view('sucursales', $data);
        $this->load->view('templates/footer', $data);
    }
    
}
