<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-08-30 01:38:31 --> Severity: error --> Exception: Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\empresa\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2025-08-30 02:03:59 --> Severity: error --> Exception: syntax error, unexpected identifier "pblic", expecting "function" or "const" C:\xampp\htdocs\empresa\application\controllers\Welcome.php 5
ERROR - 2025-08-30 02:04:21 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\controllers\Welcome.php 7
ERROR - 2025-08-30 02:04:31 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\controllers\Welcome.php 7
ERROR - 2025-08-30 02:07:23 --> Severity: error --> Exception: syntax error, unexpected token "(", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\empresa\application\controllers\Welcome.php 7
ERROR - 2025-08-30 02:10:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Pagina_model.php C:\xampp\htdocs\empresa\system\core\Loader.php 314
ERROR - 2025-08-30 02:10:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Pagina_model.php C:\xampp\htdocs\empresa\system\core\Loader.php 314
ERROR - 2025-08-30 02:11:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Pagina_model.php C:\xampp\htdocs\empresa\system\core\Loader.php 314
ERROR - 2025-08-30 02:11:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Pagina_model.php C:\xampp\htdocs\empresa\system\core\Loader.php 314
ERROR - 2025-08-30 02:11:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Pagina_model.php C:\xampp\htdocs\empresa\system\core\Loader.php 314
ERROR - 2025-08-30 02:13:26 --> 404 Page Not Found: Principal/index
ERROR - 2025-08-30 02:13:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Pagina_model.php C:\xampp\htdocs\empresa\system\core\Loader.php 314
ERROR - 2025-08-30 02:14:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Pagina_model.php C:\xampp\htdocs\empresa\system\core\Loader.php 314
ERROR - 2025-08-30 02:19:51 --> Severity: error --> Exception: syntax error, unexpected token "echo", expecting "," or ";" C:\xampp\htdocs\empresa\application\views\welcome_message.php 79
ERROR - 2025-08-30 02:36:16 --> Severity: error --> Exception: syntax error, unexpected identifier "convertir_estatus" C:\xampp\htdocs\empresa\application\helpers\funciones_helper.php 3
ERROR - 2025-08-30 02:36:41 --> Severity: error --> Exception: syntax error, unexpected token "return" C:\xampp\htdocs\empresa\application\helpers\funciones_helper.php 6
ERROR - 2025-08-30 02:36:58 --> Severity: Warning --> Undefined property: stdClass::$activo C:\xampp\htdocs\empresa\application\views\welcome_message.php 83
ERROR - 2025-08-30 02:40:33 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\empresa\application\helpers\funciones_helper.php 7
ERROR - 2025-08-30 02:41:08 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\empresa\application\helpers\funciones_helper.php 7
ERROR - 2025-08-30 02:41:10 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\empresa\application\helpers\funciones_helper.php 7
