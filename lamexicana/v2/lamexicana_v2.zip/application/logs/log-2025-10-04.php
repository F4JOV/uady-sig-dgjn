<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-04 02:09:41 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'activo'., SQL state S0022 in SQLExecDirect C:\xampp\htdocs\empresa\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-04 02:09:41 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'activo'. - Invalid query: SELECT Id, nombre_seccion, activo
FROM cat_secciones
WHERE activo = '1'
ERROR - 2025-10-04 02:13:36 --> Severity: Warning --> odbc_exec(): SQL error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'activo'., SQL state S0022 in SQLExecDirect C:\xampp\htdocs\empresa\system\database\drivers\odbc\odbc_driver.php 138
ERROR - 2025-10-04 02:13:36 --> Query error: [Microsoft][ODBC SQL Server Driver][SQL Server]Invalid column name 'activo'. - Invalid query: SELECT Id, nombre_seccion, activo
FROM cat_secciones
WHERE activo = '1'
