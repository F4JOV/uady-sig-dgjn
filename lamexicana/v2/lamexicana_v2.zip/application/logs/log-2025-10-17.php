<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-10-17 08:26:23 --> 404 Page Not Found: Home/index
ERROR - 2025-10-17 08:34:23 --> 404 Page Not Found: Home/index
ERROR - 2025-10-17 10:17:05 --> 404 Page Not Found: Sucursales/index
ERROR - 2025-10-17 22:25:51 --> Severity: error --> Exception: Unable to locate the model you have specified: MAdmin C:\xampp\htdocs\lamexicana\system\core\Loader.php 314
ERROR - 2025-10-17 22:26:12 --> Severity: error --> Exception: Unable to locate the model you have specified: MAdmin C:\xampp\htdocs\lamexicana\system\core\Loader.php 314
ERROR - 2025-10-17 22:26:47 --> Severity: error --> Exception: Unable to locate the model you have specified: MAdmin C:\xampp\htdocs\lamexicana\system\core\Loader.php 314
ERROR - 2025-10-17 22:27:08 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:27:08 --> 404 Page Not Found: Admin/css
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/js
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/js
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/js
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:27:09 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:38 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:29:39 --> 404 Page Not Found: Admin/js
ERROR - 2025-10-17 22:29:40 --> 404 Page Not Found: Admin/vendor
ERROR - 2025-10-17 22:29:40 --> 404 Page Not Found: Admin/js
ERROR - 2025-10-17 22:29:40 --> 404 Page Not Found: Admin/js
ERROR - 2025-10-17 22:37:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:37:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:37:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:37:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:37:39 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:38:00 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:38:00 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:38:00 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:38:00 --> 404 Page Not Found: Admin/img
ERROR - 2025-10-17 22:38:00 --> 404 Page Not Found: Admin/img
