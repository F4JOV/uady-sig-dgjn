<footer class="footer mt-5">
  <div class="container py-1">
    <div class="row">
      <!-- Columna 1: Logo y descripción -->
      <div class="col-md-4 mb-1 d-flex justify-content-center align-items-center">
        <a  href="<?= base_url('') ?>"><img id="logofooter" src="assets/imagenes/mexic_logo.jpg" alt="images"></a>
        
      </div>

      <!-- Columna 2: Menú del sitio -->
      <div class="col-md-4 mb-1">
        <h5 class="footer-title">Enlaces</h5>
        <ul class="footer-links list-unstyled">
          <?php if (!empty($menu)): ?>
            <?php foreach ($menu as $m): ?>
              <li>
                <a href="<?= base_url($m->url ?? '#') ?>">
                  <?= $m->nombre ?>
                </a>
              </li>
            <?php endforeach; ?>
          <?php endif; ?>
        </ul>
      </div>

      <!-- Columna 3: Contacto -->
      <div class="col-md-4 mb-1">
        <h5 class="footer-title">Contacto</h5>
        <ul class="footer-contact list-unstyled">
            <?php if (!empty($contacto) && isset($contacto[0])): ?>
                <li><i class="fas fa-map-marker-alt"></i> <?= $contacto[0]->direccion ?></li>
                <li><i class="fas fa-phone-alt"></i> <?= $contacto[0]->telefono ?></li>
                <li><i class="fas fa-envelope"></i> <?= $contacto[0]->correo_elec ?></li>
            <?php else: ?>
                <li><i class="fas fa-map-marker-alt"></i> Dirección no disponible</li>
                <li><i class="fas fa-phone-alt"></i> Teléfono no disponible</li>
                <li><i class="fas fa-envelope"></i> Correo no disponible</li>
            <?php endif; ?>
        </ul>


        <div class="footer-social mt-3">
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://x.com" target="_blank"><i class="fab fa-x-twitter"></i></a>
            <a href="https://youtube.com" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-bottom">
    <p >&copy; <?= date('Y') ?> La Mexicana. Todos los derechos reservados.</p>
  </div>
</footer>

<!-- Font Awesome (iconos) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>


<!-- Bootstrap JS -->
<script src="<?= base_url('assets/js/jquery.min.js') ?>"></script>
<script src="<?= base_url('assets/js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
