<div class="container mt-4">

  <!-- Carrusel principal -->
  <?php $this->load->view('templates/carousel'); ?>

  <div class="row mt-5">
    <div class="col-12">
      <?php if(!empty($contenido)): ?>
        <?php foreach($contenido as $c): ?>
          <?= html_entity_decode(utf8_decode($c->contenido)) ?>
        <?php endforeach; ?>
      <?php else: ?>
        <p>No hay contenido disponible por el momento.</p>
      <?php endif; ?>
    </div>
  </div>
</div>
