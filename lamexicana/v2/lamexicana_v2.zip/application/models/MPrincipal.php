<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MPrincipal extends CI_Model {

    
    public function consultar_seccion($idcatseccion){
        $sql = "EXEC pa_consultar_contenido_x_idseccion @idseccion = '".$idcatseccion."'";
        $query = $this->db->query($sql);
        return ($query) ? $query->result() : false;
    }

    // Menú superior
    public function get_menu(){
        $sql = "SELECT nombre, url FROM cat_menu WHERE estatus = 1";
        $query = $this->db->query($sql);
        return ($query) ? $query->result() : false;
    }

    public function get_contacto(){
        $sql = "SELECT direccion, telefono, correo_elec FROM cat_contacto WHERE id = 1";
        $query = $this->db->query($sql);
        return ($query) ? $query->result() : false;
    }

    // Carrusel principal
    /*
    public function get_carousel(){
        $sql = "
            SELECT c.id, i.ruta, i.nombre_archivo, c.href
            FROM cat_carousel c
            INNER JOIN cat_imagenes i ON i.id = c.idcatimagen
            WHERE i.estatus = 1 AND c.estatus = 1
            ORDER BY c.id ASC
        ";
        $query = $this->db->query($sql);
        return ($query) ? $query->result() : false;
    }
        */
    public function get_carousel($idcatseccion){
        $sql = "EXEC pa_seleccion_imagen @idseccion = '".$idcatseccion."'";
        $query = $this->db->query($sql);
        return ($query) ? $query->result() : false;
    }
}
